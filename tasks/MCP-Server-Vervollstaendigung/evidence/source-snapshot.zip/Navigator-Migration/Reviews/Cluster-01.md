# Cluster 1 Implementation Review

Reference policy: external comparison material has been removed from this historical record. Local documentation, the public contract matrix, and Navigator code and tests are authoritative. Commit IDs, findings, and reported historical gate results below retain their original provenance; this cleanup does not rerun or reaccept them.

## Point 1.1: TestKit Foundation

- Implementation base: `cb7c555611d95adc91f0bc776e609c715ee9176c` (working tree was clean).

- Existing AiNetCodeNavigator support already supplied the builder, fixtures, and basic assertions. Its tests only checked a one-project solution, one resolved type, two fixture types, and handoff ID examples; they did not prove the broader advertised behavior.
- Changes: reject duplicate project names, malformed project/document inputs, duplicate project references, and unresolved project references before creating a workspace; dispose the workspace if solution construction fails. Expand TestKit tests to cover syntax trees, valid compilations, cross-project symbol resolution, nullable and preprocessor options, metadata-reference reuse, virtual paths without filesystem writes, fixture semantics, and assertion helper contracts.
- Current-state documentation updated: [development/build-and-tests.md](../../../docs/development/build-and-tests.md).

### Verification

All official gates were executed:

| Gate | Result |
|---|---|
| `pwsh -File ./scripts/build.ps1` | Passed, 0 warnings and 0 errors |
| Focused TestKit tests (`dotnet test ... --filter FullyQualifiedName~TestKitInfrastructureTests`) | Passed, 16/16 |
| `pwsh -File ./scripts/test-integration.ps1` | Passed, 4/4 |
| `pwsh -File ./scripts/test.ps1` | Passed, 191/191 across both test projects |
| `pwsh -File ./scripts/test-fast.ps1` | Passed on the final run, 187/187 |
| `git diff --check` | Passed |

Two earlier standalone FastTests runs failed in the unrelated `HandoffHandleRegistryTests.ConcurrentRequests_AreThreadSafeAndDeduplicated` test (`19` unique IDs observed, `20` expected). The full suite and a subsequent standalone FastTests run both passed. This transient failure is recorded for the point auditor to assess.

### Independent audit

- Audit count: 1 of 3. Reviewed commit `ad26ff0709e39aae36f9a881d11932b45eeb0bbe` with `gpt-6-sol` (medium). The working tree was clean before this documentation edit.

- **P2 — Handoff assertion accepts invalid product handles.** `tests/AiNetCodeNavigator.TestKit/Assertions/NavigationAssertions.cs:17` permits `_` and `-`; `tests/AiNetCodeNavigator.FastTests/TestKit/TestKitInfrastructureTests.cs:181-182` explicitly marks both forms valid. `src/AiNetCodeNavigator.Core/Symbols/HandoffCounterAlphabet.cs:12-31` permits only ASCII letters and digits, and `IsValidHandle` uses that alphabet. Therefore `AssertValidHandoffId("h:foo_bar")` succeeds for a handle the product rejects. Align the assertion with the product validator and test both accepted and rejected boundary cases.
- **P2 — Exposed workspace does not contain the returned projects.** `tests/AiNetCodeNavigator.TestKit/Builders/TestWorkspaceBuilder.cs:93-125` starts with an `AdhocWorkspace`, then calls immutable `Solution.AddProject` and `Solution.AddProjectReference` without applying that solution to the workspace. The handle exposes both values at lines 29-31, but its `Workspace.CurrentSolution` remains empty (or contains only the empty virtual solution), while `Solution` contains the projects. The current tests at `tests/AiNetCodeNavigator.FastTests/TestKit/TestKitInfrastructureTests.cs:26-29` and `:51-53` inspect only `handle.Solution`, so this divergence is uncovered. Make both exposed views consistent and add a regression check with projects, documents and references.
- **P3 — Error-path assertions are narrower than the new validation.** `tests/AiNetCodeNavigator.TestKit/Builders/TestWorkspaceBuilder.cs:134-186` adds rejection for null specs, malformed document names/content, null metadata references, duplicate and unknown project references. `tests/AiNetCodeNavigator.FastTests/TestKit/TestKitInfrastructureTests.cs:107-125` checks only duplicate project names and an unknown reference. Add focused tests for the other public input failure cases, including the fluent entry points, to substantiate the claimed validation.
- Acceptance: fix both P2 findings and add the stated failure-path tests; rerun the affected official gates before marking the point's audit checkbox complete. No product code was changed by this audit.
- Gate evidence: the implementation review above records build, integration, full suite and final fast suite as passed on the implementation turn, with two earlier transient failures in `HandoffHandleRegistryTests.ConcurrentRequests_AreThreadSafeAndDeduplicated`. This auditor did not run a build or tests and does not independently certify those results. The transient failure is outside point 1.1 and remains a separate observation for the orchestrator.
- The Cluster 1 checklist's audit checkbox remains open for the auditor's follow-up.
- No 1.2 or 1.3 implementation work was included in this slice.

### Audit 1 Finding Fixes

- Fix base: `c4ae03c5a175605d6d0ef83385204f24fbee9638`.
- **P2, handoff alphabet:** `NavigationAssertions.AssertValidHandoffId` now calls the Core `HandoffCounterAlphabet.IsValidHandle` validator. Tests accept only alphanumeric counters and reject hyphens, underscores, malformed prefixes, empty values, and null.
- **P2, workspace consistency:** after building the immutable solution, `TestWorkspaceBuilder` applies it through `AdhocWorkspace.TryApplyChanges` and returns `Workspace.CurrentSolution`. Tests compare solution IDs, project IDs, document IDs, and project references between both views.
- **P3, validation error paths:** tests now cover null project arrays and entries, blank project names, null document lists/content, empty and directory-only document paths, null metadata references, null/blank/duplicate project-reference names, and invalid fluent builder inputs.
- Updated current-state TestKit documentation to describe the workspace consistency and product-alphabet behavior.

#### Fix Verification

| Gate | Result |
|---|---|
| `pwsh -File ./scripts/build.ps1` | Passed, 0 warnings and 0 errors |
| Focused TestKit tests (`dotnet test ... --filter FullyQualifiedName~TestKitInfrastructureTests`) | Passed, 31/31 |
| `pwsh -File ./scripts/test-fast.ps1` | Passed, 202/202 |
| `pwsh -File ./scripts/test-integration.ps1` | Passed, 4/4 |
| `pwsh -File ./scripts/test.ps1` | Passed, 206/206 across both test projects |

- The independent audit checkbox remains open for the auditor's follow-up; this implementation record does not mark the audit complete.
- No 1.2 or 1.3 implementation work was included in this fix slice.

### Independent audit 2

- Audit count: 2 of 3. Reviewed commit `56d31407410bb5ae8b8145d2a8f8cdff2ee69505` with `gpt-6-sol` (medium); the working tree was clean before this documentation edit. Scope was limited to the three findings from audit 1 and their relevant effects.
- **P2, handoff alphabet — resolved.** `tests/AiNetCodeNavigator.TestKit/Assertions/NavigationAssertions.cs:20-23` now delegates to `HandoffCounterAlphabet.IsValidHandle`; `tests/AiNetCodeNavigator.FastTests/TestKit/TestKitInfrastructureTests.cs:265-297` covers accepted alphanumeric handles and rejected hyphens, underscores, malformed prefixes, empty values, and null. The assertion now matches the product validator.
- **P2, workspace consistency — resolved.** `tests/AiNetCodeNavigator.TestKit/Builders/TestWorkspaceBuilder.cs:126-131` applies the completed immutable solution to the workspace and returns `workspace.CurrentSolution`, with failure disposal preserved by the surrounding catch. Tests at `tests/AiNetCodeNavigator.FastTests/TestKit/TestKitInfrastructureTests.cs:31-32,58-61` compare solution/project identities, document IDs, and project references across both views.
- **P3, public input failures — resolved.** `tests/AiNetCodeNavigator.FastTests/TestKit/TestKitInfrastructureTests.cs:134-211` now covers null project arrays and entries, blank names, null document lists/content, malformed paths, null metadata references, and blank/duplicate project-reference names. The fluent path and project entry points are included; `WithVirtualSolutionPath` validates blank input at `tests/AiNetCodeNavigator.TestKit/Builders/TestWorkspaceBuilder.cs:48-52`.
- **Gate evidence:** the implementer's record above reports build (0 warnings/errors), focused TestKit tests (31/31), FastTests (202/202), IntegrationTests (4/4), and full suite (206/206) passed. I inspected the current `temp/build.log`, `temp/test-fast.log`, `temp/test-integration.log`, and `temp/test.log` tails; they show those official gate outcomes. This auditor did not rerun gates. The previously observed transient HandoffHandleRegistry test failure is outside point 1.1.
- No remaining point 1.1 finding. Its audit checkbox is complete; no third point audit is needed.

## Point 1.2: Host Logging

- Implementation base: `68a5af082d3661ca1e714397840a0c572b9e522f` (working tree was clean).
- `Program.RunMainAsync` initializes the process logger before CLI dispatch and closes it at process exit. The root logger writes daily rolling files under a directory resolved from `AppContext.BaseDirectory`; MCP command diagnostics are logged while console errors use the error stream.
- Existing AiNetCodeNavigator `LoggingSetup` already configured daily file rolling, a 10 MiB size cap, 30 retained files, and an error sink. However, `Program.Main` never initialized or flushed it. The stderr sink also formatted `LogEventLevel` with a Serilog-specific `u3` format token inside C# interpolation; that throws for Error events and the sink drops the resulting exception. The sole FastTest previously checked only file output.
- Changes: initialize the logger in the executable entry point and flush it before exit; capture the process `Console.Error` writer in the error sink; format levels with an ordinary invariant enum string. Tests verify daily filename shape, file output, Error/Fatal to stderr, Information excluded from stderr, and no stdout output. An integration test launches the built host assembly and verifies silent process streams and the default log directory beside the executable.
- Current-state documentation updated: [development/build-and-tests.md](../../../docs/development/build-and-tests.md).
- Scope note: `McpServerHost` still has no MCP transport lifecycle; the real stdio session, cancellation, and shutdown checks remain under Cluster 9. Point 1.2 now proves host startup logging and stream routing.

### Verification

All official gates were executed after the final code and documentation changes:

| Gate | Result |
|---|---|
| `pwsh -File ./scripts/build.ps1` | Passed, 0 warnings and 0 errors |
| `pwsh -File ./scripts/test-fast.ps1` | Passed, 202/202 |
| `pwsh -File ./scripts/test-integration.ps1` | Passed, 5/5 |
| `pwsh -File ./scripts/test.ps1` | Passed, 207/207 across both test projects |
| `git diff --check` | Passed |

### Independent audit

- Audit count: 1 of 3. Reviewed commit `99dcf802e766f61c3bfba0ca23311e2eaf794e04` with `gpt-6-sol` (medium); the working tree was clean before this documentation edit.

- **Findings: none.** `src/AiNetCodeNavigator/Logging/LoggingSetup.cs:27-49` creates the host-relative log directory and configures daily file rolling with a size limit and retention, while the only console sink receives Error/Fatal events through `Console.Error` at lines 56-74. `src/AiNetCodeNavigator/Program.cs:7-11` initializes and flushes logging. The fast test at `tests/AiNetCodeNavigator.FastTests/Logging/LoggingSetupTests.cs:15-59` covers file naming and contents, stderr routing for Error/Fatal, exclusion of Information from stderr, and empty stdout. The process test at `tests/AiNetCodeNavigator.IntegrationTests/Mcp/McpServerIntegrationTests.cs:16-52` checks the actual entry point, stream silence, and a file beside the host assembly. The tests do not simulate a day boundary, but the configured `RollingInterval.Day` directly establishes the requested rotation behavior.
- The executable currently exits after its logging bootstrap; an active MCP transport and its lifetime belong to Cluster 9 as already recorded above. This does not leave point 1.2 open.
- **Gate evidence:** the implementer's record above reports build (0 warnings/errors), FastTests (202/202), IntegrationTests (5/5), and full suite (207/207) passed. I inspected the current `temp/build.log`, `temp/test-fast.log`, `temp/test-integration.log`, and `temp/test.log` tails; they show these results. This auditor did not run build or tests.
- The Cluster 1 checklist's point 1.2 audit checkbox is complete; no follow-up point audit is needed.
- No 1.1 or 1.3 implementation work was included in this slice.

## Point 1.3: Compilation Cache

- Implementation base: `c2c98848d96bb8293e77386797ddb76281dc5ca4` (working tree was clean).

- Existing `CompilationCacheManager` already provided separate thread-safe, case-insensitive path dictionaries for syntax trees and compilations, UTC MTime lookup, statistics, and per-file/per-project invalidation. However, `CachedTreeEntry.ContentHash` was stored but ignored on lookup; same-timestamp content changes could return a stale tree. The compilation cache had no matching source-hash safeguard, UTC `DateTime.Kind` was not enforced, and tests did not establish case-insensitive key or invalidation behavior.
- Initial changes added optional content/source hashes alongside MTime lookup and UTC timestamp validation. Audit 1 identified that callers could omit a hash and that a source-only hash did not capture every compilation input; the fixes below supersede that initial contract. File/project invalidation and case-insensitive lookup remain separate cache behaviors.
- Final scope remains the in-memory cache. It is not connected to workspace/compilation consumers yet; callers must provide every non-empty `CompilationInputFingerprint` category and update the affected category when its inputs change.

### Verification

All official gates were executed after the final implementation and documentation changes:

| Gate | Result |
|---|---|
| `pwsh -File ./scripts/build.ps1` | Passed, 0 warnings and 0 errors |
| `pwsh -File ./scripts/test-fast.ps1` | Passed, 206/206 |
| `pwsh -File ./scripts/test-integration.ps1` | Passed, 5/5 |
| `pwsh -File ./scripts/test.ps1` | Passed, 211/211 across both test projects |
| `git diff --check` | Passed |

### Independent audit

- Audit count: 1 of 3. Reviewed commit `7bfe44939f699545e6055556eb4931382689e45d` with `gpt-6-sol` (medium); the working tree was clean before this documentation edit.
- **P2 — A hashless lookup bypasses a stored hash.** `src/AiNetCodeNavigator.Core/Caching/CompilationCacheManager.cs:58-60,97-99` treats `contentHash == null` or `sourceHash == null` as a match even if the stored entry has a hash. A caller can store a tree with `(mtime=T, hash=old)`, change the file without changing T, then call `TryGetTree(path, T, out tree)` and receive the old tree. The same applies to compilations. `tests/AiNetCodeNavigator.FastTests/Caching/CompilationCacheManagerTests.cs:27-32` explicitly expects a hashless hit after a hashed store; lines 54-59 and 69-74 check mismatches only when the caller supplies a hash. This makes the advertised checksum safeguard conditional and easy to bypass. Require a matching hash for hashed entries or expose an explicitly separate MTime-only contract that cannot silently reuse a hashed entry; test omitted/mismatched/matching hashes for both caches.
- **P2 — The compilation key does not capture all changes that affect a compilation.** `src/AiNetCodeNavigator.Core/Caching/CompilationCacheManager.cs:88-124` keys a compilation by project path, the maximum source MTime, and an optional opaque `sourceHash`. Editing or removing a source file whose MTime is below another file's maximum can leave `latestSourceMTimeUtc` unchanged; changing parse/compilation options, project references, or metadata references also leaves a hash of source content unchanged. A lookup with the same maximum MTime and no hash (or an unchanged source-only hash) returns the stale `Compilation`. There is no production consumer yet to enforce a broader fingerprint. Define and test a compilation fingerprint covering every semantic input, or require explicit invalidation on each such change before integrating this cache with workspace consumers.
- Acceptance: close both stale-entry paths with focused regression tests, document the resulting hash/fingerprint contract, and rerun the affected official gates. The point 1.3 audit checkbox remains open while these findings are pending.
- **Gate evidence:** the implementer's record above reports build (0 warnings/errors), FastTests (206/206), IntegrationTests (5/5), and full suite (211/211) passed. I inspected the current `temp/build.log`, `temp/test-fast.log`, `temp/test-integration.log`, and `temp/test.log` tails; they show those results. This auditor did not run build or tests.
- No other Cluster 1 point was changed in this slice.

### Audit 1 Finding Fixes

- Fix base: `244c8893266bc33d10dad1bac960c58844315a75`.
- **P2, hashless tree lookup — fixed.** Tree-cache reuse now requires exact equality between the stored and requested hashes; two `null` hashes retain the explicit MTime-only path, while a hashed entry cannot be reused without the same hash. Regression coverage checks omitted, mismatched, and matching hashes.
- **P2, incomplete compilation key — fixed.** Compilation lookup and store now require a non-null `CompilationInputFingerprint` with non-empty hashes for source tree paths/content, per-tree parse options, assembly identity/compilation options, project-reference identities/versions, and metadata-reference identities/versions/properties/content. The fingerprint is compared by value alongside the project path and maximum source MTime. Tests vary each category independently at the same MTime, including source changes that would be hidden by another file's maximum timestamp.
- Current-state documentation describes the required fingerprint categories and the caller's responsibility to recompute hashes whenever inputs change. No production consumer exists yet, so integration must build those fingerprints from all listed inputs.

#### Fix Verification

| Gate | Result |
|---|---|
| `pwsh -File ./scripts/build.ps1` | Passed, 0 warnings and 0 errors |
| `pwsh -File ./scripts/test-fast.ps1` | Passed, 207/207 |
| `pwsh -File ./scripts/test-integration.ps1` | Passed, 5/5 |
| `pwsh -File ./scripts/test.ps1` | Passed, 212/212 across both test projects |
| `git diff --check` | Passed |

- Audit count remains 1 of 3; the findings are awaiting follow-up audit. The Cluster 1 checklist's 1.3 audit checkbox remains open.
- No other Cluster 1 point was changed in this fix slice.

### Independent audit 2

- Audit count: 2 of 3. Reviewed commit `69d18a8f3aaae767cda4ae628356b474c048c5ef` with `gpt-6-sol` (medium); the working tree was clean before this documentation edit. Scope was the two audit 1 findings, their regression tests, documentation, and affected lookup behavior.
- **P2, hashless lookup bypass — resolved.** `src/AiNetCodeNavigator.Core/Caching/CompilationCacheManager.cs:74-76` now compares stored and requested tree hashes exactly. `tests/AiNetCodeNavigator.FastTests/Caching/CompilationCacheManagerTests.cs:47-62` verifies that an omitted or changed hash misses a hashed entry and that the matching hash hits. Two null hashes retain the documented MTime-only mode; they cannot retrieve a hashed entry.
- **P2, incomplete compilation key — resolved for the cache API.** `src/AiNetCodeNavigator.Core/Caching/CompilationCacheManager.cs:20-39,104-142,190-198` requires a non-null fingerprint with non-blank fields for source trees, parse options, compilation options/assembly identity, project references, and metadata references, and compares it by value together with path and MTime. `tests/AiNetCodeNavigator.FastTests/Caching/CompilationCacheManagerTests.cs:64-92,125-152` verifies a hit for the same fingerprint, a miss when any category changes at the same maximum MTime, and rejection of missing fields. `docs/development/build-and-tests.md` states that callers must recompute category hashes when their inputs change. No production caller exists yet; the later workspace integration must compute these values from the actual project graph and references, since the cache cannot verify the contents of caller-supplied strings.
- **Gate evidence:** the implementer's record above reports build (0 warnings/errors), FastTests (207/207), IntegrationTests (5/5), and full suite (212/212) passed. I inspected the current `temp/build.log`, `temp/test-fast.log`, `temp/test-integration.log`, and `temp/test.log` tails; they show those outcomes. This auditor did not rerun build or tests.
- No point 1.3 finding remains within the standalone cache contract. Its audit checkbox is complete; no third point audit is needed.

## Cluster 1 Integration Review

- First cluster review on commit `14c1dab285dc3b29fcfa4ec79156b0ec4542ee21` with `gpt-6-sol` (medium). The working tree was clean before this documentation edit. No cluster fix round has occurred. This review checks interfaces and documentation across points 1.1-1.3 without repeating their completed point audits.
- The TestKit's `SampleCodeFixtures` supplies the in-memory solution used by the existing workspace integration test (`tests/AiNetCodeNavigator.IntegrationTests/Workspace/WorkspaceLoadingIntegrationTests.cs:30-50`). The compilation cache currently has no production caller, so its fingerprint contract is a future workspace-integration requirement, as recorded under point 1.3. `Program.Main` initializes and flushes logging but has no MCP transport yet; that boundary is assigned to Cluster 9. These planned connections are not defects in the Cluster 1 foundations.
- **P3 — Current-state test documentation overstates protocol coverage.** `docs/development/build-and-tests.md:16` calls `AiNetCodeNavigator.IntegrationTests` an “End-to-end and MCP protocol integration test suite.” The current files under that project are `WorkspaceLoadingIntegrationTests.cs` and `McpServerIntegrationTests.cs`; the latter's process test at `tests/AiNetCodeNavigator.IntegrationTests/Mcp/McpServerIntegrationTests.cs:16-52` checks logging startup and stream silence, not a JSON-RPC handshake or tool call. `README.md:7` correctly says the MCP host and tool registrations are placeholders. Update the current-state test description so it does not imply protocol verification before Cluster 9/11 supplies it.
- Acceptance: correct the integration-test description and review the affected docs for the same claim. This is cluster-level checklist work; points 1.1-1.3 remain closed. A follow-up integration review after the documentation fix is the first cluster fix round.
- **Gate evidence:** the prior implementation record reports build (0 warnings/errors), FastTests (207/207), IntegrationTests (5/5), and full suite (212/212) passed. I inspected the existing `temp/build.log`, `temp/test-fast.log`, `temp/test-integration.log`, and `temp/test.log` tails; they show those results. I did not run build or tests for this documentation-only review.

### Cluster Integration Review Fix Round 1

- Fix base: `09f157087cfd20d0a3c76999e0625ca38bcd993d`.
- Corrected the `IntegrationTests` project description in `docs/development/build-and-tests.md` to identify its current workspace-loading and host-startup coverage and state that MCP protocol handshakes and tool calls are not covered yet.
- Searched `docs/` and `README.md` for other claims of MCP protocol or end-to-end test coverage. The remaining references describe reserved stdio/logging behavior or explicitly label the host and tool registrations as placeholders; none claims that a protocol exchange is tested.
- Verification: `git diff --check` passed. This documentation-only fix did not require build or test gates.
- The follow-up Cluster 1 integration review remains pending.

### Follow-up Cluster Integration Review — Fix Round 1

- Reviewed commit `cf74539c8e791d5d6648a0047f2e9a4b8bfc5937` with `gpt-6-sol` (medium); the working tree was clean before this documentation edit. This is the review after cluster fix round 1, not another audit of points 1.1-1.3.
- **P3 documentation finding — resolved.** `docs/development/build-and-tests.md:16` now describes the integration project as workspace-loading and host-startup tests and explicitly says that MCP handshakes and tool calls are not yet covered. This matches the existing test files and `README.md:7`. A targeted search across `docs/` and `README.md` found no remaining claim of completed MCP protocol test coverage.
- The documentation change does not alter TestKit, logging, cache, or host interfaces; it introduces no new Cluster 1 integration risk. No cluster finding remains open, so the cluster loop closes after this first fix round.
- **Verification:** I reviewed the documentation diff and ran `git diff --check`; it passed. The fix is documentation-only, and I did not run build or test gates. The most recent code-gate outcomes remain the implementer's earlier reports, recorded above; they do not validate this documentation edit independently.
